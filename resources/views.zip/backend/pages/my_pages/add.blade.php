@extends('backend.layouts.master')

@section('page_title')
    {{trans('back.add_new_page')}}
@endsection

@section('title')
    {{trans('back.add_new_page')}}
@endsection

@section('content')

    <div class="row">
        <div class="col-md-12">
            <div class="card-box">
                <form action="{{route('pages.store')}}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label for="name_ar">{{trans('back.name_ar')}}</label>
                            <b class="text-danger">*</b>
                            <input type="text" class="form-control " placeholder="{{trans('back.name_ar')}}" name="name_ar" value="{{old('name_ar')}}" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="name_en">{{trans('back.name_en')}}</label>
                            <b class="text-danger">*</b>
                            <input type="text" class="form-control " placeholder="{{trans('back.name_en')}}" name="name_en" value="{{old('name_en')}}" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="slug">{{trans('back.slug')}}</label>
                            <b class="text-danger">*</b>
                            <input type="text" class="form-control slug " placeholder="{{trans('back.slug')}}" name="slug" required>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="status">{{trans('back.Status')}}</label>
                            <select name="status" class="form-control ">
                                <option value="1" {{ old('status') == 1 ? 'selected' : null }}>{{trans('back.Active')}}</option>
                                <option value="0" {{ old('status') == 0 ? 'selected' : null }}>{{trans('back.Inactive')}}</option>
                            </select>
                        </div>
                        
                        <div class="form-group col-md-6">
                            <label for="body_ar">{{trans('back.body_ar')}}</label>
                            <textarea class="form-control editor"  name="body_ar" rows="3" >{{old('body_ar')}}</textarea>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="body_en">{{trans('back.body_en')}}</label>
                            <textarea class="form-control editor"  name="body_en" rows="3" >{{old('body_en')}}</textarea>
                        </div>
                        <div class="form-group col-6">
                            <label for="meta_description_ar">{{trans('back.meta_description_ar')}}</label>
                            <textarea class="form-control"  name="meta_description_ar" rows="3">{{old('meta_description_ar')}}</textarea>
                        </div>
                        <div class="form-group col-6">
                            <label for="meta_description_en">{{trans('back.meta_description_en')}}</label>
                            <textarea class="form-control"  name="meta_description_en" rows="3">{{old('meta_description_en')}}</textarea>
                        </div>
                        <div class="form-group col-6">
                            <label for="meta_keywords_ar">{{trans('back.meta_keywords_ar')}}</label>
                            <textarea class="form-control" name="meta_keywords_ar" rows="3">{{old('meta_keywords_ar')}}</textarea>
                        </div>
                        <div class="form-group col-6">
                            <label for="meta_keywords_en">{{trans('back.meta_keywords_en')}}</label>
                            <textarea class="form-control" name="meta_keywords_en" rows="3">{{old('meta_keywords_en')}}</textarea>
                        </div>
                    </div>

                    <div class=" text-center ">
                        <button type="submit" class="btn btn-purple  mt-2 "> {{trans('back.add_new_page')}}</button>
                    </div>

                </form>
            </div>
        </div>
    </div>

@endsection



@section('js')

    <script>
        // كود تغيير المسافات ل شرطة
        $("#slug").keydown( () => {

            let slug = $("#slug").val();
            let res = slug.replace(/ /g, function(x) {
                return "-";
            });
            $("#slug").val(res);
        })
    </script>

@endsection


