@extends('backend.layouts.master')
@section('page_title')
{{ trans('back.customer_messages') }}
@endsection
@section('title')
{{ trans('back.customer_messages') }}
@endsection

@section('content')
    <div class="row">
        <div class="col-md-3 mb-1">
            @can('search_customer_message')
                <form action="{{ route('customer-messages.index') }}" method="GET" role="search">
                    <div class="input-group">
                        <input type="text" class="form-control form-control-sm" name="query" value="{{old('query', request()->input('query'))}}" placeholder="{{ __('back.search') }}.." id="query" >
                        <button class="btn btn-purple btn-sm ml-1" type="submit" title="Search">
                            <span class="fas fa-search"></span>
                        </button>
                        <a href="{{ route('customer-messages.index') }}" class="btn btn-success btn-sm ml-1 " type="button" title="Reload">
                            <span class="fas fa-sync-alt"></span>
                        </a>
                    </div>
                </form>
            @endcan
        </div>
    </div>


    <div class="row">
        <div class="col-12">

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="" class="table table-bordered text-center table-sm">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>{{trans('back.name')}}</th>
                                <th>{{trans('back.phone')}}</th>
                                <th>{{trans('back.email')}}</th>
                                <th>{{trans('back.message')}}</th>
                                <th>{{trans('back.Created_at')}}</th>
                                <th>{{trans('back.actions')}}</th>
                            </tr>
                            </thead>

                            <tbody>
                            @foreach($customer_messages as $key => $customer_message)
                                <tr>
                                    <td>{{$key + 1}}</td>
                                    <td>{{$customer_message->name}}</td>
                                    <td>{{$customer_message->phone}}</td>
                                    <td>{{$customer_message->email}}</td>
                                    <td>{{$customer_message->message}}</td>
                                    <td>{{$customer_message->created_at}}</td>
                                    <td>
                                        @can('delete_customer_message')
                                            <a href="" class="btn btn-danger btn-xs ml-1 " data-toggle="modal" data-target="#delete_customer_message{{$customer_message->id}}">
                                                {{trans('back.Delete')}}
                                            </a>
                                        @endcan
                                        @include('backend.pages.customer_messages.delete')
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>

                        {!! $customer_messages->appends(Request::all())->links() !!}
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- end row -->

@endsection


@section('js')

    <script src="//cdn.ckeditor.com/4.15.0/full/ckeditor.js"></script>
    <script>
        CKEDITOR.replace('editor', {
            language: 'ar',
            height: 500
        });
    </script>

@endsection
