@extends('frontend.layouts.weekend_master')

@section('page_title', app()->getLocale() == 'ar' ? 'اتصل بنا' : 'Contact Us')

@section('css')
<style>
    /* Font Settings for Arabic */
    @if(app()->getLocale() == 'ar')
    body, h1, h2, h3, h4, h5, h6, p, span, div, a, button, input, select, textarea, * {
        font-family: 'Tajawal', sans-serif !important;
    }
    @endif
    /* Hero Section */
    .contact-hero {
        background: linear-gradient(135deg, rgba(18, 118, 100, 0.95) 0%, rgba(18, 118, 100, 0.85) 100%), 
                    url('https://images.unsplash.com/photo-1423666639041-f56000c27a9a?w=1920&q=80') center/cover;
        min-height: 350px;
        display: flex;
        align-items: center;
        position: relative;
    }
    
    /* Contact Form Section */
    .contact-section {
        padding: 80px 0;
    }
    
    .contact-form-card {
        background: white;
        border-radius: 20px;
        padding: 40px;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
    }
    
    .form-control, .form-select {
        border: 2px solid #e9ecef;
        border-radius: 10px;
        padding: 12px 20px;
        font-size: 15px;
        transition: all 0.3s ease;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: #127664;
        box-shadow: 0 0 0 0.2rem rgba(18, 118, 100, 0.1);
    }
    
    .form-label {
        font-weight: 600;
        color: #495057;
        margin-bottom: 8px;
    }
    
    /* Contact Info Cards */
    .contact-info-card {
        background: white;
        border-radius: 15px;
        padding: 30px;
        text-align: center;
        transition: all 0.3s ease;
        height: 100%;
        border: 2px solid transparent;
    }
    
    .contact-info-card:hover {
        transform: translateY(-5px);
        border-color: #127664;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    
    .contact-icon {
        width: 70px;
        height: 70px;
        background: linear-gradient(135deg, #127664, #159265);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        font-size: 28px;
        color: white;
    }
    
    /* Map Section */
    .map-container {
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        height: 450px;
    }
    
    /* FAQ Section */
    .faq-section {
        background: #f8f9fa;
        padding: 80px 0;
    }
    
    .accordion-item {
        border: none;
        border-radius: 15px !important;
        margin-bottom: 15px;
        overflow: hidden;
    }
    
    .accordion-button {
        background: white;
        color: #1a1a1a;
        font-weight: 600;
        padding: 20px 25px;
        border: none;
        box-shadow: none !important;
    }
    
    .accordion-button:not(.collapsed) {
        background: linear-gradient(135deg, #127664, #159265);
        color: white;
    }
    
    .accordion-button::after {
        background-image: none;
        content: '\f107';
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
        font-size: 18px;
    }
    
    .accordion-button:not(.collapsed)::after {
        transform: rotate(180deg);
    }
    
    .accordion-body {
        padding: 25px;
        background: white;
    }
    
    /* Social Links */
    .social-links {
        display: flex;
        gap: 15px;
        justify-content: center;
        margin-top: 20px;
    }
    
    .social-link {
        width: 45px;
        height: 45px;
        background: #f8f9fa;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #127664;
        text-decoration: none;
        transition: all 0.3s ease;
    }
    
    .social-link:hover {
        background: #127664;
        color: white;
        transform: translateY(-3px);
    }
    
    /* Submit Button */
    .btn-submit {
        background: linear-gradient(135deg, #127664, #159265);
        color: white;
        border: none;
        padding: 14px 40px;
        border-radius: 10px;
        font-weight: 600;
        font-size: 16px;
        transition: all 0.3s ease;
    }
    
    .btn-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 25px rgba(18, 118, 100, 0.3);
        color: white;
    }
    
    /* Success Alert Animation */
    @keyframes slideInDown {
        from {
            transform: translateY(-100%);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
    
    .alert-success {
        animation: slideInDown 0.5s ease;
    }
    
    /* Success Icon Animation */
    @keyframes checkmark {
        0% {
            transform: scale(0) rotate(45deg);
        }
        50% {
            transform: scale(1.2) rotate(45deg);
        }
        100% {
            transform: scale(1) rotate(45deg);
        }
    }
    
    .fa-check-circle {
        animation: checkmark 0.5s ease 0.3s;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .contact-hero {
            min-height: 250px;
        }
        
        .contact-hero h1 {
            font-size: 2rem !important;
        }
        
        .contact-section {
            padding: 50px 0;
        }
        
        .contact-form-card {
            padding: 25px;
        }
        
        .map-container {
            height: 300px;
        }
        
        .contact-info-card {
            margin-bottom: 20px;
        }
    }
</style>
@endsection

@section('content')

<!-- Hero Section -->
<section class="contact-hero">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb bg-transparent p-0">
                        <li class="breadcrumb-item"><a href="{{ route('weekend.home') }}" class="text-white-50">{{ app()->getLocale() == 'ar' ? 'الرئيسية' : 'Home' }}</a></li>
                        <li class="breadcrumb-item active text-white">{{ app()->getLocale() == 'ar' ? 'اتصل بنا' : 'Contact Us' }}</li>
                    </ol>
                </nav>
                <h1 class="display-4 fw-bold text-white mb-3">{{ app()->getLocale() == 'ar' ? 'اتصل بنا' : 'Contact Us' }}</h1>
                <p class="lead text-white mb-0">{{ app()->getLocale() == 'ar' ? 'نحن هنا لمساعدتك. تواصل معنا في أي وقت!' : 'We are here to help you. Contact us anytime!' }}</p>
            </div>
        </div>
    </div>
</section>

<!-- Contact Info Cards -->
<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="contact-info-card">
                    <div class="contact-icon">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <h5 class="mb-3">{{ app()->getLocale() == 'ar' ? 'اتصل بنا' : 'Call Us' }}</h5>
                    @if($contact_us->phone)
                    <p class="mb-2"><a href="tel:{{ $contact_us->phone }}" class="text-decoration-none text-dark">{{ $contact_us->phone }}</a></p>
                    @endif
                    @if($contact_us->whatsapp)
                    <p class="mb-0"><a href="https://wa.me/{{ $contact_us->whatsapp }}" class="text-decoration-none text-dark"><i class="fab fa-whatsapp"></i> {{ $contact_us->whatsapp }}</a></p>
                    @endif
                </div>
            </div>
            <div class="col-md-4">
                <div class="contact-info-card">
                    <div class="contact-icon">
                        <i class="fas fa-envelope"></i>
                    </div>
                    <h5 class="mb-3">{{ app()->getLocale() == 'ar' ? 'راسلنا' : 'Email Us' }}</h5>
                    @if($contact_us->email)
                    <p class="mb-0"><a href="mailto:{{ $contact_us->email }}" class="text-decoration-none text-dark">{{ $contact_us->email }}</a></p>
                    @endif
                </div>
            </div>
            <div class="col-md-4">
                <div class="contact-info-card">
                    <div class="contact-icon">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <h5 class="mb-3">{{ app()->getLocale() == 'ar' ? 'زورونا' : 'Visit Us' }}</h5>
                    @if($contact_us->address_ar || $contact_us->address_en)
                    <p class="mb-0 text-muted">{{ app()->getLocale() == 'ar' ? $contact_us->address_ar : $contact_us->address_en }}</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Form & Map Section -->
<section class="contact-section">
    <div class="container">
        <div class="row g-5">
            <!-- Contact Form -->
            <div class="col-lg-6">
                <div class="contact-form-card">
                    <h3 class="mb-4">{{ app()->getLocale() == 'ar' ? 'أرسل لنا رسالة' : 'Send Us a Message' }}</h3>
                    
                    <!-- Success Message -->
                    @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert" style="border-radius: 10px; background: linear-gradient(135deg, #2ecc71 0%, #27ae60 100%); border: none; color: white;">
                        <div class="d-flex align-items-center">
                            <i class="fas fa-check-circle fa-2x me-3"></i>
                            <div>
                                <strong>{{ app()->getLocale() == 'ar' ? 'تم الإرسال بنجاح!' : 'Successfully Sent!' }}</strong>
                                <p class="mb-0">{{ session('success') }}</p>
                            </div>
                        </div>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close" style="filter: brightness(0) invert(1);"></button>
                    </div>
                    @endif
                    
                    <!-- Error Messages -->
                    @if($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert" style="border-radius: 10px;">
                        <ul class="mb-0">
                            @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    @endif
                    
                    <form action="{{ route('send_messages') }}" method="POST">
                        @csrf
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">{{ app()->getLocale() == 'ar' ? 'الاسم الأول' : 'First Name' }} *</label>
                                <input type="text" class="form-control" name="first_name" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">{{ app()->getLocale() == 'ar' ? 'الاسم الأخير' : 'Last Name' }} *</label>
                                <input type="text" class="form-control" name="last_name" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">{{ app()->getLocale() == 'ar' ? 'البريد الإلكتروني' : 'Email' }} *</label>
                                <input type="email" class="form-control" name="email" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">{{ app()->getLocale() == 'ar' ? 'رقم الهاتف' : 'Phone Number' }}</label>
                                <input type="tel" class="form-control" name="phone">
                            </div>
                            <div class="col-12">
                                <label class="form-label">{{ app()->getLocale() == 'ar' ? 'الموضوع' : 'Subject' }} *</label>
                                <select class="form-select" name="subject" required>
                                    <option value="">{{ app()->getLocale() == 'ar' ? 'اختر الموضوع' : 'Select Subject' }}</option>
                                    <option value="general">{{ app()->getLocale() == 'ar' ? 'استفسار عام' : 'General Inquiry' }}</option>
                                    <option value="booking">{{ app()->getLocale() == 'ar' ? 'مشكلة في الحجز' : 'Booking Issue' }}</option>
                                    <option value="payment">{{ app()->getLocale() == 'ar' ? 'مشكلة في الدفع' : 'Payment Issue' }}</option>
                                    <option value="complaint">{{ app()->getLocale() == 'ar' ? 'شكوى' : 'Complaint' }}</option>
                                    <option value="suggestion">{{ app()->getLocale() == 'ar' ? 'اقتراح' : 'Suggestion' }}</option>
                                    <option value="partnership">{{ app()->getLocale() == 'ar' ? 'شراكة' : 'Partnership' }}</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label">{{ app()->getLocale() == 'ar' ? 'الرسالة' : 'Message' }} *</label>
                                <textarea class="form-control" name="message" rows="5" required></textarea>
                            </div>
                            <div class="col-12">
                                <button type="submit" class="btn btn-submit w-100">
                                    {{ app()->getLocale() == 'ar' ? 'إرسال الرسالة' : 'Send Message' }}
                                    <i class="fas fa-paper-plane ms-2"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Map -->
            <div class="col-lg-6">
                <div class="map-container">
                    @if($contact_us->map)
                        {!! $contact_us->map !!}
                    @else
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d233668.38703692693!2d58.24195915!3d23.58589!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e91ffa8879aafc9%3A0xdb53876d0d79a72c!2sMuscat%2C%20Oman!5e0!3m2!1sen!2s!4v1635959040967!5m2!1sen!2s" 
                        width="100%" 
                        height="100%" 
                        style="border:0;" 
                        allowfullscreen="" 
                        loading="lazy">
                    </iframe>
                    @endif
                </div>
                
                <!-- Social Links -->
                <div class="text-center mt-4">
                    <h5 class="mb-3">{{ app()->getLocale() == 'ar' ? 'تابعنا على' : 'Follow Us' }}</h5>
                    <div class="social-links">
                        @if($contact_us->facebook_url)
                        <a href="{{ $contact_us->facebook_url }}" target="_blank" class="social-link">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        @endif
                        @if($contact_us->twitter_url)
                        <a href="{{ $contact_us->twitter_url }}" target="_blank" class="social-link">
                            <i class="fab fa-twitter"></i>
                        </a>
                        @endif
                        @if($contact_us->instagram_url)
                        <a href="{{ $contact_us->instagram_url }}" target="_blank" class="social-link">
                            <i class="fab fa-instagram"></i>
                        </a>
                        @endif
                        @if($contact_us->linkedin_url)
                        <a href="{{ $contact_us->linkedin_url }}" target="_blank" class="social-link">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        @endif
                        @if($contact_us->youtube_url)
                        <a href="{{ $contact_us->youtube_url }}" target="_blank" class="social-link">
                            <i class="fab fa-youtube"></i>
                        </a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="faq-section">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="display-5 fw-bold">{{ app()->getLocale() == 'ar' ? 'الأسئلة الشائعة' : 'Frequently Asked Questions' }}</h2>
            <p class="lead text-muted">{{ app()->getLocale() == 'ar' ? 'إجابات على الأسئلة الأكثر شيوعاً' : 'Answers to the most common questions' }}</p>
        </div>
        
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="accordion" id="faqAccordion">
                    @forelse($faqs as $index => $faq)
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="faq{{ $faq->id }}">
                            <button class="accordion-button {{ $index == 0 ? '' : 'collapsed' }}" type="button" data-bs-toggle="collapse" data-bs-target="#collapse{{ $faq->id }}">
                                {{ app()->getLocale() == 'ar' ? $faq->question_ar : $faq->question_en }}
                            </button>
                        </h2>
                        <div id="collapse{{ $faq->id }}" class="accordion-collapse collapse {{ $index == 0 ? 'show' : '' }}" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                {{ app()->getLocale() == 'ar' ? $faq->answer_ar : $faq->answer_en }}
                            </div>
                        </div>
                    </div>
                    @empty
                    <div class="text-center py-5">
                        <p class="text-muted">{{ app()->getLocale() == 'ar' ? 'لا توجد أسئلة شائعة حالياً' : 'No FAQs available at the moment' }}</p>
                    </div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</section>

@endsection

@section('js')
<!-- Sweet Alert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // Form validation
    (function() {
        'use strict';
        var forms = document.querySelectorAll('.needs-validation');
        Array.prototype.slice.call(forms).forEach(function(form) {
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    })();
    
    // Auto hide success message after 5 seconds
    document.addEventListener('DOMContentLoaded', function() {
        const successAlert = document.querySelector('.alert-success');
        if (successAlert) {
            setTimeout(function() {
                // Fade out animation
                successAlert.style.transition = 'opacity 0.5s ease';
                successAlert.style.opacity = '0';
                
                // Remove from DOM after animation
                setTimeout(function() {
                    successAlert.remove();
                }, 500);
            }, 5000); // Hide after 5 seconds
        }
        
        // Clear form after successful submission
        @if(session('success'))
        document.querySelector('form').reset();
        // Scroll to top to see the success message
        window.scrollTo({
            top: document.querySelector('.contact-form-card').offsetTop - 100,
            behavior: 'smooth'
        });
        
        // Show Sweet Alert
        Swal.fire({
            icon: 'success',
            title: '{{ app()->getLocale() == "ar" ? "تم الإرسال بنجاح!" : "Successfully Sent!" }}',
            text: '{{ session("success") }}',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            toast: true,
            position: 'top-end',
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });
        @endif
    });
    
    // Add loading state to submit button
    document.querySelector('form').addEventListener('submit', function(e) {
        const submitBtn = this.querySelector('.btn-submit');
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>' + 
            ('{{ app()->getLocale() }}' === 'ar' ? 'جاري الإرسال...' : 'Sending...');
        submitBtn.disabled = true;
    });
</script>
@endsection
