@extends('frontend.layouts.master_page')

@section('page_title')
    {{ app()->getLocale() == 'ar' ? $page->name_ar : $page->name_en }}
@endsection

@section('meta_keywords')
    {{ app()->getLocale() == 'ar' ? $page->meta_keywords_ar : $page->meta_keywords_en }}
@endsection

@section('meta_description')
    {{ app()->getLocale() == 'ar' ? $page->meta_description_ar : $page->meta_description_en }}
@endsection

@section('content')
    <section class="wrapper">
        <div class="image-wrapper bg-cover bg-image d-flex align-items-center justify-content-center mx-auto">
            <div class="container py-sm-5 py-xxl-20">
                <div class="row">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/">{{ __('back.home') }}</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                {{ app()->getLocale() == 'ar' ? $page->name_ar : $page->name_en }}
                            </li>
                        </ol>
                    </nav>
                    <div class="col-12">
                        <h4>{{ app()->getLocale() == 'ar' ? $page->name_ar : $page->name_en }}</h4>
                        {!! app()->getLocale() == 'ar' ? $page->body_ar : $page->body_en !!}
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
