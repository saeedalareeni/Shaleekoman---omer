<!DOCTYPE html>
<html lang="ar" dir="rtl" >

@include('frontend.layouts.head')

<body class="overflow-x-hidden" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">

    {{--Header--}}
    <div class="content-wrapper">
        @include('frontend.layouts.header')
    </div>

    @yield('content')

    @include('frontend.layouts.footer')

    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>

    @include('frontend.layouts.script')
    
    
</body>

</html>
