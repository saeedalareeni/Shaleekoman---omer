@php
    $contact = \App\Models\Contact::first();
    $about = \App\Models\About::first();
    $locale = app()->getLocale();
@endphp



<div class="footer-wrapper position-relative w-100">
    <div class="footer-outer-container"></div>
    <footer class="footer-container py-6 mx-auto">
        <div class="footer-logo text-center">
            @if($about)
                <img src="{{asset(App\Models\Setting::first()->logo)}}" alt="{{ $locale == 'ar' ? $about->company_name_ar : $about->company_name_en }}" class="w-75">
            @endif
        </div>
        <div class="container">
            <div class="row text-center text-md-start mt-8 mt-md-10">

                <div class="col-md-4 mb-4">
                    <h3 class="footer-title fs-18"> {{ App::getLocale()== 'ar' ? $about->company_name_ar : $about->company_name_en }}</h3>
                    <div class="footer-links">
                        <p>
                            {{ App::getLocale()== 'ar' ? $about->about_ar : $about->about_en }}
                        </p>
                    </div>
                </div>

                <div class="col-md-4 mb-4">
                    <h3 class="footer-title fs-18"> {{ __('back.quick_links') }}</h3>
                    <div class="footer-links">
                        <a href="{{ route('showAllChalet') }}"> {{ trans('back.offer_weekend') }} </a>
                        <a href="{{ route('about_us') }}">{{ __('back.about_us') }}</a>
                        <a href="{{ route('contact_us') }}">{{ __('back.contact_us') }}</a>
                        <a href="{{ route('all-posts') }}">{{ __('back.blog') }}</a>
                        <a href="{{ route('terms') }}">{{ __('back.terms') }}</a>
                        @foreach (App\Models\Page::where('status',1)->get() as $page)
                            <a href="{{ route('page', ['slug' => $page->slug]) }}"> {{ App::getLocale()== 'ar' ? $page->name_ar : $page->name_en }}</a>
                        @endforeach
                    </div>
                </div>

                <div class="col-md-4 mb-4">
                    <h3 class="footer-title fs-18">{{ __('back.contact_us') }}</h3>

                    <div class="footer-links">
                        <a class="" href="mailto:{{ $contact->email}}"> {{ __('back.email') }} : {{ $contact->email }}</a>
                        <a class="" href="tel:{{ $contact->phone }}"> {{ __('back.phone') }} : {{ $contact->phone }}</a>
                        <a class=""> {{ __('back.address') }} : {{ App::getLocale()== 'ar' ? $contact->address_ar : $contact->address_en }}</a>
                    </div>

                    @if($contact)
                        <div class="social-icons">
                            @if($contact->facebook_url)
                            <a href="{{ $contact->facebook_url}}" class="facebook-icon" target="_blank"><i class="fab fa-facebook"></i></a>
                            @endif
                            @if($contact->instagram_url)
                            <a href="{{ $contact->instagram_url}}" class="instagram-icon" target="_blank"><i class="fab fa-instagram"></i></a>
                            @endif
                            @if($contact->youtube_url)
                            <a href="{{ $contact->youtube_url}}" class="youtube-icon" target="_blank"><i class="fab fa-youtube"></i></a>
                            @endif
                            @if($contact->email)
                            <a href="mailto:{{ $contact->email}}" class="email-icon"><i class="far fa-envelope"></i></a>
                            @endif
                            @if($contact->twitter_url)
                            <a href="{{ $contact->twitter_url }}" class="twitter-icon" target="_blank"><i class="fab fa-twitter"></i></a>
                            @endif
                            @if($contact->linkedin_url)
                            <a href="{{ $contact->linkedin_url }}" class="linkedin-icon" target="_blank"><i class="fab fa-linkedin"></i></a>
                            @endif
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </footer>
</div>

