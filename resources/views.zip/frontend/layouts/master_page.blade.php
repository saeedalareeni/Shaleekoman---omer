<!DOCTYPE html>
<html lang="ar" dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}" >

@include('frontend.layouts.head')

<body dir="{{ app()->getLocale() == 'ar' ? 'rtl' : 'ltr' }}">

    <div class="content-wrapper bg-soft-ash">

        @include('frontend.layouts.pageheader')

        @yield('content')

    </div>

    @include('frontend.layouts.footer')

    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>

    @include('frontend.layouts.script')
</body>

</html>
